import xbmcaddon

myaddon = xbmcaddon.Addon()
addonID = xbmcaddon.Addon('plugin.video.netvideos')

danhmucphim=myaddon.getSetting('danhmucphim')
hdonline_view=myaddon.getSetting('hdonline_view')
vuahd_view=myaddon.getSetting('vuahd_view')
hdviet_view=myaddon.getSetting('hdviet_view')
hayhaytv_view=myaddon.getSetting('hayhaytv_view')
dangcaphd_view=myaddon.getSetting('dangcaphd_view')
megabox_view=myaddon.getSetting('megabox_view')
phimmoi_view=myaddon.getSetting('phimmoi_view')
hdcaphe_view=myaddon.getSetting('hdcaphe_view')
phimgiaitri_view=myaddon.getSetting('phimgiaitri_view')
